21/10/18
Diego Fernandez
H2 G1

  # Subject
Create an HTML page with a futuristic interface. It must be composed mainly of HTML/CSS and must contain interactions and animations.


  # Theme
I try to create a modern car interface.


  # Process
* I choose an interface in internet and i try to do something like the picture
* Creation of the two images used (The two car) on Illustrator
* Web development


  # Features
* When hovering the 0, a counter starts up to 990. It was created in JS
* When hovering the yellow lozenge, an explicative text go in the middle of the screen
* BOOST BAR: the bars moove with a scaleX
* Kw BAR: the bars moove with a scaleX
* Nm BAR: the bars moove with a scaleX
* PERFORMANCES BAR: All the bars moove with a scaleX and a delay
* Rayon X bar: they moove with an animation
* Rotate bar : they moove with a transform rotate



  # Difficulties and learning
* This is my first web project and I don't think I have a perfect code but I'm quite proud because I've managed to do a lot of things or I thought I couldn't do it. I managed to make my work responsive, make animations and put everything well in my page. I think it has allowed me to learn a lot from my mistakes

* To make my work responsive I had to replace all my "px" in "vw" which was very long
